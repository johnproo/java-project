/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Bruce Elea
 */
class T {

    public T(String Fillet_O_Fish, String ChickenBurger, String ChickenLegend, String ChickenBurgerM, String CheeseBurger, String BaconCheeseBurger, String HotMilk, String MilkShake, String VanillaCone, String ClassicVanilla, String VanillaMilkShake, String ChocolateMilkShake) {
    }

    void setVisible(boolean b) {
        //throw new UnsupportedOperationException("Not yet implemented");
    }

}
