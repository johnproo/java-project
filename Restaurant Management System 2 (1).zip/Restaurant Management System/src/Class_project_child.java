/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Bruce Elea
 */
public class Class_project_child extends Class_project{

}
