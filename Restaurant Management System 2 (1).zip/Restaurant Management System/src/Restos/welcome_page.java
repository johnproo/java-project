/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Restos;

/**
 *
 * @author Bruce Elea
 */
class welcome_page {

    void Show() {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

}
