/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package admin;

/**
 *
 * @author Bruce Elea
 */
class Home {

    void pack() {
       // throw new UnsupportedOperationException("Not yet implemented");
    }

    void setDefaultCloseOperation(int DISPOSE_ON_CLOSE) {
        //throw new UnsupportedOperationException("Not yet implemented");
    }

    void setLocationRelativeTo(Object object) {
       // throw new UnsupportedOperationException("Not yet implemented");
    }

    void setVisible(boolean b) {
       // throw new UnsupportedOperationException("Not yet implemented");
    }

}
